## TODOs for Today's Episode 

### Get Started with Audio Recording Functionality

- Build out our Audio Recorder Components
- animate our TextInputArea when record button is tapped
- create AudioRecorder Scaffolding


  
