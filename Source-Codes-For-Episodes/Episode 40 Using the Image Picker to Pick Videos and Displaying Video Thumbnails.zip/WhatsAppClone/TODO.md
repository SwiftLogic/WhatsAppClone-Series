## TODOs for Today's Episode 

### We Need to Show selected video in our MediaAttachment Preview Component

We need to transer the video data. To do that we are going to be Using the Transferable protocol, that's going to help us in converting the video's URL into a SentTransferredFile, which let's copy the movie's URL into our documents directory as a “mov”, file by using the importing closure


- create a dataModel that can power all media types in our MediaAttachmentPreview Component
- Transfer the movie URL from PhotoPicker to a DataModel that our app can access
- generate a thumbnail for the video using the AVAssetImageGenerator


  
