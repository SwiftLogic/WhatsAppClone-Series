## TODOs for Today's Episode 

### Complete Our VideoPicker Functionality


- create a media player view to play recorded audios and selected videos
- remove an item from MediaAttachmentPreview
- animate our MediaAttachmentPreview


  
