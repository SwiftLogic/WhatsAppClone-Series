## TODOs for Today's Episode 

### Complete Our VideoPicker Functionality


- remove an item from MediaAttachmentPreview
- animate our MediaAttachmentPreview
- slight UX Clean up


  
