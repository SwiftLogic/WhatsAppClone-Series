//
//  WhatsAppCloneApp.swift
//  WhatsAppClone
//
//  Created by Osaretin Uyigue on 2/6/24.
//

import SwiftUI

@main
struct WhatsAppCloneApp: App {
    var body: some Scene {
        WindowGroup {
            MainTabView()
        }
    }
}
